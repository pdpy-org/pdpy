# pdpy Extension for VS Code

vscode-pdpy is a [pdpy](https://github.com/fdch/pdpy) extension
for [Visual Studio Code](https://code.visualstudio.com/).
The extension currently supports text highlighting.

## Features

- Syntax highlighting

## Future Improvements

- Improved text highlighting
- Auto-complete

## License

vscode-pdpy is licensed under the
[MIT License](https://opensource.org/licenses/MIT).
